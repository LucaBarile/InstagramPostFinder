// Author: Luca Barile - https://lucabarile.github.io/

package lucabarile.igpf;

// indent: CTRL+ALT+L
// run the app until the next breakpoint: ALT+F9
/*
    most relevant files:
    activity_main.xml
    list_view_border.xml
    text_view_layout.xml
    strings.xml
    AndroidManifest.xml
    MainActivity.java
    Post.java
*/

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.android.volley.RequestQueue;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import android.widget.ArrayAdapter;

public class MainActivity extends AppCompatActivity
{
    // list of IG query IDs - https://github.com/InstaPy/instapy-research/blob/master/api/old_api/README.md
    private static final String USER_POSTS = "17888483320059182"; // <-- we're interested in this
    // private static final String POST_FOR_TAGS = "17875800862117404";
    // private static final String USER_FOLLOWING = "17874545323001329";
    // private static final String USER_FOLLOWERS= "17851374694183129";
    // private static final String LIKE_ON_POSTS = "17864450716183058";
    // private static final String COMMENTS_ON_POSTS = "17852405266163336";
    // private static final String POST_ON_FEED = "17842794232208280";
    // private static final String FEED_PROFILE_SUGGESTIONS = "17847560125201451";
    // private static final String POSTS_SUGGESTIONS = "17863787143139595";

    // https://carloshenriquereis-17318.medium.com/how-to-get-data-from-a-public-instagram-profile-edc6704c9b45
    // the query hash is used instead of GraphQL ID to improve GraphQL performance
    // private static final String USER_POSTS_BY_HASH = "56a7068fea504063273cc2120ffd54f3";

    // the less GET requests we make, the better -> IG blocks our IP after n requests -> error 401
    private static final int POSTS_AT_A_TIME = 50; // MIN=1 | MAX=50 (on 2023-02-23)

    // IG could change the GraphQL APIs -> tested on 2023-03-06
    private static final String IG_GRAPH_API = "https://www.instagram.com/graphql/query/?query_id=";
    private static final String POST_URL = "https://www.instagram.com/p/{post_shortcode}/";

    // error 401 (IG blocked our IP) -> increase this value OR POSTS_AT_A_TIME
    private static final int REQUESTS_INTERVAL = 1; // seconds to wait between JSON(s) requests

    // ---------- global variables ----------
    private String username;
    private String userID;
    private String keyword;
    private String appFilesDir;
    private int numPosts = -1; // the user could have 0 posts
    private ArrayList<String> allUserJson = new ArrayList<>();
    private ArrayList<Post> userPosts = new ArrayList<>();
    // --------------------------------------

    // ---------- views references ----------
    private Button btnSearch;
    private EditText txtUsername;
    private EditText txtKeyword;

    private ListView lvMatches;
    private ProgressBar prgBar;
    // --------------------------------------

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // lock the screen orientation to portrait -> avoid wrong views layout
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        // enable application's dark theme
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);

        // remove Android App Title Bar (hide the IGPF writing)
        getSupportActionBar().hide();

        // set the color of the status bar -> I don't like the default color (dark purple)
        this.getWindow().setStatusBarColor(Color.rgb(51,153,255));

        // avoid to move the progress bar up (which is align to bottom) when the soft keyboard comes up (this happens when the user insert the username or the keyword)
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);

        // ---------- views references and settings ----------
        btnSearch = (Button) findViewById(R.id.btnSearch);
        btnSearch.setBackgroundColor(Color.rgb(51,153,255));

        txtUsername = (EditText) findViewById(R.id.txtUsername);
        txtUsername.setOnLongClickListener(this::txtUsernameOnLongClickListener); // fill with my IG username

        txtKeyword = (EditText) findViewById(R.id.txtKeyword);

        lvMatches = (ListView) findViewById(R.id.lvMatches);
        lvMatches.setOnItemClickListener(this::lvMatchesOnItemClickListener); // open the selected post on the browser
        // lvMatches.setDivider(new ColorDrawable(Color.rgb(51,153,255))); // set in activity_main.xml
        // lvMatches.setDividerHeight(2); // set in activity_main.xml

        prgBar  = (ProgressBar) findViewById(R.id.prgBar);
        prgBar.getProgressDrawable().setColorFilter(Color.rgb(51,153,255), android.graphics.PorterDuff.Mode.SRC_IN);
        // ---------------------------------------------------

        // adapt the views layout to the device display
        setViewsLayout();
    }

    public void searchPost(View view) // called when btnSearch is clicked
    {
        // initializing variables
        appFilesDir = getApplicationContext().getFilesDir().getAbsolutePath();
        allUserJson = new ArrayList<>();
        numPosts = -1;
        prgBar.setProgress(0);
        prgBar.setMax(0);
        username = txtUsername.getText().toString().toLowerCase(); // toLowerCase avoid json files loading problem and other problems
        keyword = txtKeyword.getText().toString().toLowerCase(); // // toLowerCase avoid post's caption match problems and other problems
        userID = "";

        // hide the keyboard -> the user can see the progress bar
        try
        {
            InputMethodManager imm = (InputMethodManager)getSystemService(INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
        }
        catch (Exception e) {} // keyboard doesn't open OR the keyboard hide button has been used

        // inputs validation -> check if the username and the keyword are well formatted
        if(isUsernameValid() == false || isKeywordValid() == false)
            return;

        if (isDeviceConnected() && !areSavedJsonFilesUpToDate()) // device connected && saved json files not updated?
            getUserIDandData(); // if the user ID is found -> call getAllUserJsonData (which will download the updated json files form IG)
        else // device not connected?
            if (areUserJsonPresent()) // json(s) already present? -> use them (even if they're non updated) to find matches
            {
                Toast.makeText(getApplicationContext(), "Searching in offline mode...", Toast.LENGTH_SHORT).show();
                loadAllUserSavedJson();
                getAllUserPostsFromJson();
                searchKeywordInAllUserPosts();
            }
            else // device not connected ad no saved json(s)? -> no way... the user must connect his device
                Toast.makeText(getApplicationContext(), "No Internet connection.", Toast.LENGTH_LONG).show();
    }

    private void getAllUserJsonData() // GET request for the first POSTS_AT_A_TIME user's posts
    {
        // https://www.instagram.com/graphql/query/?query_id=17888483320059182&variables={"id":"1290429459","first":50}
        // IG could change the GraphQL APIs -> tested on 2023-03-06
        String url = IG_GRAPH_API +
                USER_POSTS +
                "&variables={%22id%22:%22" +
                userID +
                "%22,%22first%22:" +
                POSTS_AT_A_TIME +
                "}";

        // volley library is used for asynchronous HTTP GET requests
        StringRequest request = new StringRequest(url, this::jsonStringListener, this::jsonStringErrorListener);
        RequestQueue rQueue = Volley.newRequestQueue(MainActivity.this);
        rQueue.add(request);
    }

    private void jsonStringListener(String json) // handles HTTP responses and creates new GET requests
    {
        allUserJson.add(json); // save every received json -> we can search matches offline if the device isn't online

        try
        {
            // data -> user -> edge_owner_to_timeline_media -> count = number of all user posts
            // IG could change this hierarchy -> tested on 2023-03-07
            JSONObject jO = new JSONObject(json);
            JSONObject data = jO.getJSONObject("data");
            JSONObject user = data.getJSONObject("user");
            JSONObject edge_owner_to_timeline_media = user.getJSONObject("edge_owner_to_timeline_media");

            // set the max value of the progress bar just one time
            if(numPosts == -1) // -1 only for the first received json
            {
                numPosts = Integer.parseInt(edge_owner_to_timeline_media.getString("count")); // total number of user posts
                prgBar.setMax(numPosts);
            }

            // posts pagination
            // data -> user -> edge_owner_to_timeline_media -> page_info -> has_next_page = true -> there are other user posts to download
            JSONObject page_info = edge_owner_to_timeline_media.getJSONObject("page_info");
            String has_next_page = page_info.getString("has_next_page");

            RequestQueue rQueue = null;

            if (has_next_page.equals("true")) // there are other user posts to download -> download them
            {
                prgBar.setProgress(prgBar.getProgress() + POSTS_AT_A_TIME);

                // data -> user -> edge_owner_to_timeline_media -> page_info -> end_cursor = continue from here to get the next posts
                String end_cursor = page_info.getString("end_cursor");

                // https://www.instagram.com/graphql/query/?query_id=17888483320059182&variables={"id":"1290429459","first":50,"after":"end_cursor"}
                // IG could change the GraphQL API -> tested on 2023-03-07
                String url = IG_GRAPH_API +
                        USER_POSTS +
                        "&variables={%22id%22:%22" +
                        userID +
                        "%22,%22first%22:" +
                        POSTS_AT_A_TIME +
                        ",%22after%22:%22" +
                        end_cursor +
                        "%22}";

                // GET request for the next 50 user's posts
                StringRequest request = new StringRequest(url, this::jsonStringListener, this::jsonStringErrorListener);
                rQueue = Volley.newRequestQueue(MainActivity.this);
                waitNseconds(REQUESTS_INTERVAL); // needed to avoid Instagram block -> Error 401 (too many request in a short time)
                rQueue.add(request);
            }
            else // I've all the user posts -> save them locally and look for matches
            {
                // rQueue.getCache().clear();
                // rQueue.stop();
                saveAllUserJsonData(); // save all the user json(s) locally (for offline search purposes)
                getAllUserPostsFromJson(); // json(s) parsing -> get caption for each post (and other info...)
                searchKeywordInAllUserPosts(); // find the posts whose caption contains the keyword
                prgBar.setProgress(0); // reset the progress bar for future searches
            }
        }
        catch (JSONException e) // json parsing error (generally when some attribute of the hierarchy is missing)
        {
            Toast.makeText(getApplicationContext(), "jsonStringListener() - Error while parsing json data.", Toast.LENGTH_LONG).show();
        }
    }

    private void jsonStringErrorListener(VolleyError volleyError) // handles HTTP responses & requests errors
    {
        if (volleyError.networkResponse.statusCode == 401) // excessive IG requests -> IP temporarily banned -> try to find matches via saved json files
        {
            loadAllUserSavedJson(); // load all user saved json files

            if (allUserJson.size() == 0) // there are no json files saved for this user -> no way... the post can't be searched -> user must change IP (or wait for unban)
            {
                Toast.makeText(getApplicationContext(), "jsonStringErrorListener() - Instagram has temporarily blocked your IP due to excessive requests.", Toast.LENGTH_LONG).show();
                return;
            }
            else // there are saved json files -> try to find matches via saved json(s)
            {
                getAllUserPostsFromJson(); // json(s) parsing -> get caption for each post (and other info...)
                searchKeywordInAllUserPosts(); // find the posts which caption contains the keyword
            }
        }
        else // other errors...
            Toast.makeText(getApplicationContext(), "jsonStringErrorListener() - Error when receiving json files from Instagram.", Toast.LENGTH_LONG).show();
    }

    private void saveAllUserJsonData() // save all the downloaded user's json files locally -> for offline searches purposes
    {
        // appFilesDir = data/data/lucabarile.igpf/files (on Android Device File Explorer)
        String userJsonFolder = appFilesDir + "/" + username;

        File f = new File(userJsonFolder); // path of the folder where the user's json files are locally saved
        File[] savedJson = f.listFiles(); // list of user's json files saved

        if(f.exists() == false) // user's json(s) folder doesn't exist?
        {
            try
            {
                // no error if one or more folder already exists
                Files.createDirectories(Paths.get(userJsonFolder)); // create it (it's the first time we're downloading his posts)
            }
            catch (IOException e)
            {
                Toast.makeText(getApplicationContext(), "saveAllUserJsonData() - Error while creating the user json folder", Toast.LENGTH_LONG).show();
            }
        }

        // do old users json(s) already exist? -> delete them all
        if(savedJson != null)
            for(File json : savedJson)
                json.delete();

        // save the newly downloaded user's json files in the folder
        File jsonFile;
        FileOutputStream stream;

        for (int i=0; i<allUserJson.size(); i++)
        {
            jsonFile = new File(userJsonFolder, i + ".json");

            try
            {
                stream = new FileOutputStream(jsonFile);
                stream.write(allUserJson.get(i).getBytes());
                stream.close();
            }
            catch (Exception e)
            {
                Toast.makeText(getApplicationContext(),"saveAllUserJsonData() - Error while saving the user json files.", Toast.LENGTH_LONG).show();
            }
        }
    }

    private void searchKeywordInAllUserPosts() // add to the ListView all the user's posts whose captions contain the keyword
    {
        ArrayList <String> matchingList = new ArrayList<>(); // will contains all the user's posts whose captions contain the keyword

        // every post added into matchingList will be added to the ListView as TextView
        // every textView uses the text_view_layout -> the text is centered and has a custom size (20sp) and color (white)
        ArrayAdapter adapter = new ArrayAdapter<>(getApplicationContext(), R.layout.text_view_layout, matchingList);
        lvMatches.setAdapter(adapter);

        // search all the user's posts whose captions contain the keyword and add them to the matchingList
        for(Post p : userPosts)
            if(p.caption.toLowerCase().contains(keyword)) // toLowerCase because contains() is case sensitive (keyword is already in lower case (set in onCreate()))
                matchingList.add(p.short_code); // the short_code is needed if the user want to open le post's link

        if (matchingList.isEmpty())
            Toast.makeText(getApplicationContext(), "No matches found.", Toast.LENGTH_LONG).show();
        else
            adapter.notifyDataSetChanged(); // refresh alla the TextView contained in the ListView -> the user can see the matches
    }

    private boolean txtUsernameOnLongClickListener(View view) // easter egg -> quick way to enter my username ;)
    {
        txtUsername.setText("barol92");
        return true;
    }

    // open the IG post clicked by the user in the ListView via browser
    private void lvMatchesOnItemClickListener(AdapterView<?> adapterView, View view, int i, long l)
    {
        String shortcode = (String)adapterView.getItemAtPosition(i);
        String url = POST_URL.replace("{post_shortcode}", shortcode);

        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        startActivity(browserIntent);
    }

    private void getAllUserPostsFromJson() // for each post get id, short_code, display_url and caption from its relative json
    {
        userPosts.clear(); // in case this is not the first post searched

        Post p;

        for (String json : allUserJson)
        {
            try
            {
                /*
                    post ID: data -> user -> edge_owner_to_timeline_media -> edges -> {num_post} -> node -> id
                    post short_code: data -> user -> edge_owner_to_timeline_media -> edges -> {num_post} -> node -> shortcode
                    post display_url: data -> user -> edge_owner_to_timeline_media -> edges -> {num_post} -> node -> display_url
                    post caption: data -> user -> edge_owner_to_timeline_media -> edges -> {num_post} -> node -> edge_media_to_caption -> edges -> 0 -> node -> text
                */

                JSONObject jO = new JSONObject(json);
                JSONObject data = jO.getJSONObject("data");
                JSONObject user = data.getJSONObject("user");
                JSONObject edge_owner_to_timeline_media = user.getJSONObject("edge_owner_to_timeline_media");
                JSONArray edges = edge_owner_to_timeline_media.getJSONArray("edges"); // user's posts contained in this json

                int numPosts = edges.length(); // the last json could contains less than POSTS_AT_A_TIME posts

                for (int i=0; i<numPosts; i++) // normally 50 edges for each json (the last could have less posts (edges))
                {
                    p = new Post();

                    JSONObject edge = edges.getJSONObject(i);
                    JSONObject node = edge.getJSONObject("node");
                    p.id = node.getString("id");
                    p.short_code = node.getString("shortcode");
                    p.display_url = node.getString("display_url");
                    JSONObject edge_media_to_caption = node.getJSONObject("edge_media_to_caption");
                    JSONArray edges2 = edge_media_to_caption.getJSONArray("edges");
                    JSONObject edge0 = edges2.getJSONObject(0); // <-- can be 0 if the post has no caption! -> call JSONException e -> ignore this post
                    JSONObject node2 = edge0.getJSONObject("node");
                    p.caption = node2.getString("text");

                    userPosts.add(p);
                }
            }
            catch (JSONException e) {} // typically invoked when a post has no caption -> error in [JSONObject edge0 = edges2.getJSONObject(0);] -> ignore the current post
        }
    }

    private boolean isDeviceConnected() // check if the device is connected
    {
        boolean connected = false;

        try
        {
            ConnectivityManager cm = (ConnectivityManager)getApplicationContext().getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo nInfo = cm.getActiveNetworkInfo();
            connected = (nInfo != null && nInfo.isAvailable() && nInfo.isConnected());
        }
        catch (Exception e)
        {
            Toast.makeText(getApplicationContext(), "isDeviceConnected() - Error while checking internet connection.", Toast.LENGTH_LONG).show();
        }
        return connected;
    }

    private boolean areUserJsonPresent() // check if json files have already been saved for the current user
    {
        String userJsonFolder = appFilesDir + "/" + username;
        File folder = new File(userJsonFolder);
        File[] savedJson = folder.listFiles();

        if(folder.exists() == false || savedJson == null)
            return false;

        return true;
    }

    private void loadAllUserSavedJson() // load into allUserJson array the current user saved json files (if any)
    {
        allUserJson.clear(); // in case other json files have already been loaded

        FileInputStream fis = null;
        StringBuffer fileContent;
        byte[] buffer;
        int n;

        String userJsonFolder = appFilesDir + "/" + username; // data/data/lucabarile.igpf/files/{username} (on Android Device File Explorer)
        File folder = new File(userJsonFolder);
        File[] savedJson = folder.listFiles();

        if (savedJson == null) // no saved json(s)? -> stop the loading process
            return;

        for(File json : savedJson)
        {
            try
            {
                fis = new FileInputStream(json.getAbsolutePath());
            }
            catch (FileNotFoundException e)
            {
                Toast.makeText(getApplicationContext(), "loadAllUserSavedJson() - Error while opening the file input stream.", Toast.LENGTH_LONG).show();
            }

            fileContent = new StringBuffer("");
            buffer = new byte[1024];

            try
            {
                while ((n = fis.read(buffer)) != -1)
                    fileContent.append(new String(buffer, 0, n));
            }
            catch (IOException e)
            {
                Toast.makeText(getApplicationContext(), "loadAllUserSavedJson() - Error while reading from a saved json file.", Toast.LENGTH_LONG).show();
            }

            allUserJson.add(fileContent.toString());
        }
    }

    private void waitNseconds(int n) // puts the thread that called this function on hold for n seconds -> used when downloading user jason files
    {
        try
        {
            Thread.sleep(n*1000);
        }
        catch (InterruptedException e)
        {
            Toast.makeText(getApplicationContext(), "waitNseconds() - Error while waiting before sending the next request.", Toast.LENGTH_LONG).show();
        }
    }

    private boolean isNumeric(String s) // check if the string is a number
    {
        try
        {
            Double id = Double.parseDouble(s); // s isn't numeric? -> parsing exception -> return false
            return true;
        }
        catch(NumberFormatException e)
        {
            return false;
        }
    }

    private boolean isUsernameValid() // true if it's not empty AND doesn't contain spaces AND isn't longer than 30 characters
    {
        // IG Username rules: can't be longer than 30 characters AND can only contain letters, numbers, periods (.) and underscores

        if(username.equals(""))
        {
            Toast.makeText(getApplicationContext(), "You must insert the username.", Toast.LENGTH_LONG).show();
            return false;
        }

        if(username.contains(" "))
        {
            Toast.makeText(getApplicationContext(), "The username mustn't contain spaces.", Toast.LENGTH_LONG).show();
            return false;
        }

        if(username.length() > 30)
        {
            Toast.makeText(getApplicationContext(), "The username mustn't be longer than 30 characters.", Toast.LENGTH_LONG).show();
            return false;
        }

        return true;
    }

    private boolean isKeywordValid() // true if it's not empty AND doesn't contain spaces
    {
        if(keyword.equals(""))
        {
            Toast.makeText(getApplicationContext(), "You must insert the keyword.", Toast.LENGTH_LONG).show();
            return false;
        }

        if(keyword.contains(" "))
        {
            Toast.makeText(getApplicationContext(), "The keyword mustn't contain spaces.", Toast.LENGTH_LONG).show();
            return false;
        }

        return true;
    }

    private boolean areSavedJsonFilesUpToDate() // true if the user's saved json files are up to date
    {
        String userJsonFolder = appFilesDir + "/" + username; // data/data/lucabarile.igpf/files/username (on Android Device File Explorer)
        File f = new File(userJsonFolder);
        File[] savedJson = f.listFiles();

        if (savedJson == null) // no saved json files? -> we must download them
            return false;

        // there are saved json files -> load them if they're up to date
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String lastModDate = sdf.format(new Date(savedJson[0].lastModified())); // savedJson != null -> at least one json file (the num 0)
        String today = sdf.format(new Date());

        return (today.equals(lastModDate)) ? true : false;
    }

    private void setViewsLayout() // adapt the views layout to the device display
    {
        // ------ get display info -----
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);

        int displayHeight = displayMetrics.heightPixels;
        int display10pct_y = (int) Math.round(0.1 * displayHeight); // views height
        int display5pct_y = (int) Math.round(0.05 * displayHeight); // first view (btnSearch) padding from the top | last view (prgBar) padding from the bottom
        int display3pct_y = (int) Math.round(0.03 * displayHeight); // padding among the views
        int display60pct_y = (int) Math.round(0.60 * displayHeight); // lvMatches height (remaining free display space)

        int displayWidth = displayMetrics.widthPixels;
        int display80pct_x = (int) Math.round(0.8 * displayWidth); // 80% displayWidth -> width of all the views
        //int viewsPaddingLeft = (int) 0.1 * displayWidth; // 10% displayWidth -> 10% [view_80%] 10% -> centered -> (already set via activity_main.xml)
        // -----------------------------

        // ------ set views width to 80% display width ------
        btnSearch.getLayoutParams().width = display80pct_x;
        txtUsername.getLayoutParams().width = display80pct_x;
        txtKeyword.getLayoutParams().width = display80pct_x;
        lvMatches.getLayoutParams().width = display80pct_x;
        prgBar.getLayoutParams().width = display80pct_x;
        // --------------------------------------------------

        // -------------- set views height --------------
        btnSearch.getLayoutParams().height = display10pct_y;
        txtUsername.getLayoutParams().height = display10pct_y;
        txtKeyword.getLayoutParams().height = display10pct_y;
        lvMatches.getLayoutParams().height = displayHeight - display60pct_y; // the sum of all the other view heights + paddings + a little gap (to be sure) =~ 60% displayHeight -> lvMatches height  = 40% displayHeight
        prgBar.getLayoutParams().height = display3pct_y;
        // ----------------------------------------------

        // ------------------ set views margins ------------------
        ViewGroup.MarginLayoutParams btnSearchParams = (ViewGroup.MarginLayoutParams) btnSearch.getLayoutParams();
        ViewGroup.MarginLayoutParams txtUsernameParams = (ViewGroup.MarginLayoutParams) txtUsername.getLayoutParams();
        ViewGroup.MarginLayoutParams txtKeywordParams = (ViewGroup.MarginLayoutParams) txtKeyword.getLayoutParams();
        ViewGroup.MarginLayoutParams lvMatchesParams = (ViewGroup.MarginLayoutParams) lvMatches.getLayoutParams();
        ViewGroup.MarginLayoutParams prgBarParams = (ViewGroup.MarginLayoutParams) prgBar.getLayoutParams();

        btnSearchParams.topMargin = display5pct_y;
        txtUsernameParams.topMargin = display3pct_y;
        txtKeywordParams.topMargin = display3pct_y;
        lvMatchesParams.topMargin = display3pct_y;
        prgBarParams.bottomMargin = display5pct_y;
        // -------------------------------------------------------
    }

    private void getUserIDandData() // get the user ID from username and then user posts data (json files)
    {
        Thread thread = new Thread()
        {
            @Override
            public void run()
            {
                try
                {
                    // connect to the Instagram user page
                    URL url = new URL("https://www.instagram.com/" + username + "/"); // in the html code there is the user ID (profilePage_UserID) [tested on 2023-03-12]
                    URLConnection con = url.openConnection();

                    // avoid java.lang.NullPointerException: charsetName
                    String contentEncoding = con.getContentEncoding();
                    if (contentEncoding == null)
                        contentEncoding = "ISO-8859-1";

                    // find the line which contains the user ID (from the html code of his Instagram page)
                    String htmlLine;
                    BufferedReader br = new BufferedReader(new InputStreamReader(con.getInputStream(), contentEncoding));

                    while ((htmlLine = br.readLine()) != null)
                        if (htmlLine.contains("profilePage_")) // remember that contains() IS CASE SENSITIVE!!
                            break; // not interested in other html data

                    br.close();

                    // parse the line to get the user ID
                    int startID = htmlLine.indexOf("profilePage_") + 12; // 12 = length of "profilePage_"
                    htmlLine = htmlLine.substring(startID, startID + 30); // The Instagram ID should always consist of 10 digits but I'm not sure and Instagram may add more in the future
                    int endID = htmlLine.indexOf("\""); // the first occurrence of "
                    userID = htmlLine.substring(0, endID); // save the ID into the global variable
                }
                catch (Exception ex)
                {
                    showMessage("getUserIDandData() - Error while getting user ID."); // runOnUiThread (necessary)
                    return;
                }

                // user ID found successfully; is it right? -> No? -> Error message -> return
                if(userID.equals("") || isNumeric(userID) == false)
                {
                    showMessage("getUserIDandData() - The user ID found is invalid."); // runOnUiThread (necessary)
                    return;
                }

                // user ID is valid -> get all the user posts data (contained in the json files)
                getAllUserJsonData();
            }
        };
        thread.start();
    }

    private void showMessage(String message) // show the message on UI Thread (avoid a thread Looper.prepare() error) -> used by a Thread (created in getUserIDandData())
    {
        runOnUiThread(new Runnable()
        {
            public void run()
            {
                Toast.makeText(getApplicationContext(), message, Toast.LENGTH_LONG).show();
            }
        });
    }
}