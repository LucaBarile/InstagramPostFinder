package lucabarile.igpf;

public class Post
{
    String id = "";             // node -> id
    String display_url = "";    // node -> display_url
    String caption = "";        // node -> edge_media_to_caption -> edges -> 0 -> node -> text
    String short_code = "";     // node -> shortcode
}